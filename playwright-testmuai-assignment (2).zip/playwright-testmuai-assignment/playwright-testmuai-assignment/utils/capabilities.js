// utils/capabilities.js
//
// Builds the LT:Options capability payload TestMu AI expects for each
// browser / OS combination. Values are pulled from environment variables
// so credentials never get committed to source control.
//
// Required env vars (export before running, or put in a .env file loaded
// by your shell):
//   LT_USERNAME    -> your TestMu AI username (Profile page)
//   LT_ACCESS_KEY  -> your TestMu AI access key (Profile page)

const cp = require('child_process');

function playwrightVersion() {
  try {
    return cp.execSync('npx playwright --version').toString().trim().split(' ')[1];
  } catch {
    return undefined;
  }
}

const BUILD_NAME = 'Playwright 101 - Selenium Playground Assignment';

// One entry per Playwright test `project`. The project name is used as the
// key so the fixture can look up the right capability object per worker.
const capabilitiesMap = {
  'chrome-win10': {
    browserName: 'Chrome',
    browserVersion: 'latest',
    'LT:Options': {
      platform: 'Windows 10',
      build: BUILD_NAME,
      name: 'Scenario Suite - Chrome on Windows 10',
      user: process.env.LT_USERNAME,
      accessKey: process.env.LT_ACCESS_KEY,
      network: true,   // network logs
      video: true,     // video recording
      console: true,   // console logs
      // screenshots are captured explicitly in the tests (see tests/*.spec.js)
      playwrightClientVersion: playwrightVersion(),
    },
  },
  'firefox-macos': {
    browserName: 'pw-firefox',
    browserVersion: 'latest',
    'LT:Options': {
      platform: 'macOS Sonoma',
      build: BUILD_NAME,
      name: 'Scenario Suite - Firefox on macOS',
      user: process.env.LT_USERNAME,
      accessKey: process.env.LT_ACCESS_KEY,
      network: true,
      video: true,
      console: true,
      playwrightClientVersion: playwrightVersion(),
    },
  },
};

module.exports = { capabilitiesMap };
