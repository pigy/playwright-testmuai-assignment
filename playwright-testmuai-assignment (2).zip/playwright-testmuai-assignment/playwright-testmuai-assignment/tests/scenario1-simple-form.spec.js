const { test, expect } = require('../fixtures/testmuai-fixture');

test.describe('Scenario 1 - Simple Form Demo', () => {
  test('message entered is echoed back under Your Message', async ({ page }) => {
    await page.goto('/selenium-playground/');

    // Locator type #1: link/text locator
    await page.getByRole('link', { name: 'Simple Form Demo' }).click();

    // 3. URL validation
    await expect(page).toHaveURL(/simple-form-demo/);

    // 4. Variable holding the string value to test with
    const messageToTest = 'Welcome to TestMu AI';

    // Locator type #2: CSS id selector, scoped to the actual <input> and to
    // the currently visible copy (the page renders duplicate hidden markup
    // for other breakpoints, which reuses the same id).
    const messageInput = page.locator('input#user-message:visible');
    await messageInput.fill(messageToTest);

    // Locator type #3: role-based locator for the button
    await page.getByRole('button', { name: 'Get Checked Value' }).click();

    // 7. Validate the right-hand panel echoes the same message
    const outputPanel = page.locator('#message:visible');
    await expect(outputPanel).toHaveText(messageToTest);
  });
});