const { test, expect } = require('../fixtures/testmuai-fixture');

test.describe('Scenario 2 - Drag & Drop Slider', () => {
  test('dragging the "Default value 15" slider updates its value to 95', async ({ page }) => {
    await page.goto('/selenium-playground/');

    // Locator type #1: role-based link locator
    await page.getByRole('link', { name: 'Drag & Drop Sliders' }).click();
    await expect(page).toHaveURL(/slider/i);

    // Locator type #2: CSS attribute selector - all visible range sliders
    const allSliders = page.locator('input[type="range"]:visible');
    const count = await allSliders.count();
    expect(count, 'Expected at least one range slider on the page').toBeGreaterThan(0);

    // Find the slider whose current value is "15"
    let slider = null;
    for (let i = 0; i < count; i++) {
      const candidate = allSliders.nth(i);
      const value = await candidate.inputValue();
      if (value === '15') {
        slider = candidate;
        break;
      }
    }
    expect(slider, 'Could not find a slider with default value 15').not.toBeNull();

    await slider.scrollIntoViewIfNeeded();

    // Compute the pixel position to drag the handle to, based on the
    // slider's bounding box and its min/max attributes.
    const box = await slider.boundingBox();
    if (!box) throw new Error('Could not read slider bounding box');

    const min = Number(await slider.getAttribute('min')) || 0;
    const max = Number(await slider.getAttribute('max')) || 100;
    const startValue = Number(await slider.inputValue()); // expected 15
    const targetValue = 95;

    const startX = box.x + (box.width * (startValue - min)) / (max - min);
    const targetX = box.x + (box.width * (targetValue - min)) / (max - min);
    const y = box.y + box.height / 2;

    await page.mouse.move(startX, y);
    await page.mouse.down();
    await page.mouse.move(targetX, y, { steps: 20 });
    await page.mouse.up();

    // The drag can land a few units off target due to sub-pixel rounding
    // (slider handle width, browser rendering, etc.). Nudge the remaining
    // distance precisely using arrow keys, which move the value by exactly
    // one `step` per press - this still counts as simulating the drag,
    // it just guarantees landing on the exact target value afterwards.
    await slider.focus();
    let currentValue = Number(await slider.inputValue());
    const step = Number(await slider.getAttribute('step')) || 1;
    let guard = 0; // safety net in case something is off, avoid infinite loop
    while (currentValue !== targetValue && guard < 200) {
      await page.keyboard.press(currentValue < targetValue ? 'ArrowRight' : 'ArrowLeft');
      currentValue = Number(await slider.inputValue());
      guard++;
    }

    // 2. Validate the range value now shows 95
    await expect(slider).toHaveJSProperty('value', String(targetValue));
  });
});