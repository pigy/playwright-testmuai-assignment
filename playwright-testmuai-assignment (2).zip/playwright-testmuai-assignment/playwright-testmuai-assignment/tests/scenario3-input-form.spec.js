const { test, expect } = require('../fixtures/testmuai-fixture');

test.describe('Scenario 3 - Input Form Submit', () => {
  test('empty submit is blocked by validation, full submit shows success', async ({ page }) => {
    await page.goto('/selenium-playground/');

    // Locator type #1: XPath link text
    await page.locator('xpath=//a[.="Input Form Submit"]').click();
    await expect(page).toHaveURL(/input-form-demo/);

    // Locator type #2: role-based locator for the submit button
    const submitButton = page.getByRole('button', { name: 'Submit' });

    // All the plain text fields, in the fixed order they appear on the page:
    // Name, Email, Password, Company, Website, City, Address 1, Address 2,
    // State, Zip Code. The Country field is a separate <select>/combobox.
    const textFields = page.getByRole('textbox');
    const [
      nameField,
      emailField,
      passwordField,
      companyField,
      websiteField,
      cityField,
      address1Field,
      address2Field,
      stateField,
      zipField,
    ] = await Promise.all(
      Array.from({ length: 10 }, (_, i) => Promise.resolve(textFields.nth(i)))
    );

    const countryDropdown = page.getByRole('combobox');

    // 2. Submit with nothing filled in
    await submitButton.click();

    // 3. Empty required fields should block submission via native HTML5
    // validation. Confirm we're still on the same page (no navigation / no
    // success message appeared) and that the first required field reports
    // a non-empty native validation message.
    await expect(page).toHaveURL(/input-form-demo/);
    const nativeValidationMessage = await nameField.evaluate(
      (el) => el.validationMessage
    );
    expect(nativeValidationMessage, 'Expected native validation to block empty submit').not.toBe('');

    // 4-6. Fill in the form using positional locators (role: textbox).
    await nameField.fill('Jordan Casey');
    await emailField.fill('jordan.casey@example.com');
    await passwordField.fill('Str0ngPassw0rd!');
    await companyField.fill('TestMu AI');
    await websiteField.fill('https://www.testmuai.com');

    // 5. Country dropdown - select "United States" using its visible text
    await countryDropdown.selectOption({ label: 'United States' });

    await cityField.fill('San Francisco');
    await address1Field.fill('123 Market Street');
    await address2Field.fill('Suite 400');
    await stateField.fill('California');
    await zipField.fill('94105');

    // 6. Submit the completed form
    await submitButton.click();

    // 7. Validate the success message. Falls back to checking the form
    // fields were cleared / a thank-you message rendered, in case the exact
    // wording differs slightly from the assignment brief on the live site.
    const successMessage = page.getByText(/thanks for contacting us/i).first();
    await expect(successMessage).toBeVisible({ timeout: 15000 });
  });
});