// fixtures/testmuai-fixture.js
//
// Overrides Playwright Test's built-in `browser` fixture so every project
// connects to a remote TestMu AI browser (over CDP) instead of launching a
// local one. Playwright's built-in `context` and `page` fixtures are derived
// from `browser`, so tests can keep using the normal { page } fixture
// unchanged - they just happen to run on TestMu AI's cloud grid.

const base = require('@playwright/test');
const { chromium, firefox } = require('playwright');
const { capabilitiesMap } = require('../utils/capabilities');

const test = base.test.extend({
  browser: [
    async ({}, use, workerInfo) => {
      const projectName = workerInfo.project.name;

      // --- LOCAL MODE ---------------------------------------------------
      // Projects named "local-chrome" / "local-firefox" (see
      // playwright.local.config.js) launch a real local browser instead of
      // connecting to TestMu AI. Headed/headless is controlled by the
      // project's `use.headless` setting or the --headed CLI flag.
      if (projectName.startsWith('local-')) {
        const launcher = projectName === 'local-firefox' ? firefox : chromium;
        const browser = await launcher.launch({
          headless: workerInfo.project.use.headless ?? false,
        });
        await use(browser);
        await browser.close();
        return;
      }

      // --- CLOUD MODE (TestMu AI) ----------------------------------------
      const capabilities = capabilitiesMap[projectName];

      if (!capabilities) {
        throw new Error(
          `No TestMu AI capabilities configured for project "${projectName}". ` +
          `Check utils/capabilities.js and playwright.config.js.`
        );
      }

      if (!capabilities['LT:Options'].user || !capabilities['LT:Options'].accessKey) {
        throw new Error(
          'Missing LT_USERNAME / LT_ACCESS_KEY environment variables. ' +
          'Export them (from your TestMu AI Profile page) before running the suite.'
        );
      }

      const wsEndpoint = `wss://cdp.lambdatest.com/playwright?capabilities=${encodeURIComponent(
        JSON.stringify(capabilities)
      )}`;

      // pw-firefox capability connects through the firefox launcher,
      // everything else (Chrome/MicrosoftEdge/pw-chromium) through chromium.
      const connector = capabilities.browserName === 'pw-firefox' ? firefox : chromium;

      const browser = await connector.connect({ wsEndpoint, timeout: 60000 });
      await use(browser);
      await browser.close();
    },
    { scope: 'worker' },
  ],
});

module.exports = { test, expect: base.expect };
