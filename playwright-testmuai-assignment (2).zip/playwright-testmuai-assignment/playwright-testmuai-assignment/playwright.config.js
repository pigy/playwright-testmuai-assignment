import { defineConfig, devices } from "@playwright/test";

export default defineConfig({
  testDir: "./tests",
  timeout: 60000,
  fullyParallel: true,
  workers: 3,
  use: {
    baseURL: 'https://www.lambdatest.com',
    video: 'off',
    trace: 'on',
    screenshot: 'on',
  },

  projects: [
    { name: "chrome-win10" },
    { name: "firefox-macos" },
  ],
});