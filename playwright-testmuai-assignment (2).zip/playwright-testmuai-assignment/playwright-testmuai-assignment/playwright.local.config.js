// playwright.local.config.js
//
// Use this config to run the SAME test files locally in a real, visible
// (headed) browser - useful for debugging before you push to TestMu AI.
// It does NOT touch TestMu AI / does NOT need LT_USERNAME or LT_ACCESS_KEY.
//
// Run with:
//   npx playwright test --config=playwright.local.config.js --headed

const { defineConfig } = require('@playwright/test');

module.exports = defineConfig({
  testDir: './tests',
  timeout: 60_000,
  expect: { timeout: 10_000 },
  fullyParallel: false,
  workers: 1,
  retries: 0,
  reporter: [['list']],
  use: {
    baseURL: 'https://www.testmuai.com',
    headless: false,      // overridden to true automatically if --headed is not passed and you prefer headless
    screenshot: 'on',
    trace: 'on',
    actionTimeout: 15_000,
    navigationTimeout: 30_000,
  },
  projects: [
    {
      name: 'local-chrome',
      use: { headless: false },
    },
  ],
});
