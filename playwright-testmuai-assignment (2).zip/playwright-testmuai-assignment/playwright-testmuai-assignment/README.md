# Playwright 101 - TestMu AI Selenium Playground Assignment

Automates the three assigned test scenarios against TestMu AI's Selenium
Playground and runs them **in parallel on two browser/OS combinations** on
the TestMu AI cloud grid (Chrome on Windows 10, Firefox on macOS).

## Project layout

```
playwright-testmuai-assignment/
├── playwright.config.js         # 2 projects = 2 parallel cloud sessions
├── fixtures/
│   └── testmuai-fixture.js      # connects the `browser` fixture to TestMu AI over CDP
├── utils/
│   └── capabilities.js          # LT:Options capability objects per project
├── tests/
│   ├── scenario1-simple-form.spec.js
│   ├── scenario2-slider.spec.js
│   └── scenario3-input-form.spec.js
└── package.json
```

## 1. Prerequisites

- Node.js 18+
- A TestMu AI account (sign up with the same email you used for
  certification registration - includes 100 free automation minutes)
- Your **Username** and **Access Key** from the TestMu AI Profile page

## 2. Install dependencies

```bash
cd playwright-testmuai-assignment
npm install
```

## 3. Set your credentials

```bash
export LT_USERNAME="your-testmuai-username"
export LT_ACCESS_KEY="your-testmuai-access-key"
```

(On Windows PowerShell: `$env:LT_USERNAME="..."` / `$env:LT_ACCESS_KEY="..."`.)

## 4. Run the suite

```bash
npx playwright test
```

`playwright.config.js` defines two projects - `chrome-win10` and
`firefox-macos` - and `workers: 2`, so both sessions are dispatched to the
TestMu AI grid **at the same time**. Each session name is visible on your
TestMu AI Automation Dashboard, grouped under the build
"Playwright 101 - Selenium Playground Assignment".

To run a single combination only:

```bash
npx playwright test --project=chrome-win10
```

## 5. Logs, video, network, console

All of these are enabled per the assignment's requirements:

- `network: true`, `video: true`, `console: true` are set in
  `utils/capabilities.js` (`LT:Options`) for every session - these are the
  same flags produced by TestMu AI's **Desired Capabilities Generator**.
- `screenshot: 'on'` and `trace: 'on'` are set in `playwright.config.js` so
  Playwright also captures its own screenshots/trace per step, viewable via
  `npx playwright show-report` after a run.
- Video recording, network logs, and console logs for the cloud sessions
  themselves are viewable on the TestMu AI Automation Dashboard, under each
  Test Session ID.

## 6. Locators used (3+ types, per requirement)

Across the three specs the suite mixes:

- **CSS id** locators (`#user-message`, `#name`, `#company`, `#city`, ...)
- **Role-based** locators (`getByRole('link', ...)`, `getByRole('button', ...)`)
- **XPath** locators (slider label lookup, `Input Form Submit` link)
- **Attribute/name** locators (`input[name="email"]`, `select[name="country"]`)

## 7. Adjusting the browser/OS combinations

Edit `utils/capabilities.js` to change `platform` / `browserName` /
`browserVersion` for either project (keys must match the project names in
`playwright.config.js`). Use the TestMu AI **Desired Capabilities
Generator** in your dashboard to confirm currently supported platform
strings before changing them.

## 8. Notes on selectors

The exact `id`/`name` attributes for the Input Form Submit and slider pages
are based on TestMu AI's/LambdaTest's published Selenium Playground markup.
If TestMu AI's DOM has since changed slightly, open browser DevTools on the
live page and adjust the locators in `tests/scenario3-input-form.spec.js`
and `tests/scenario2-slider.spec.js` accordingly - the fallback comma-separated
locators (e.g. `input[name="address1"], #address1`) are there to make that
easy.

## Submission checklist (per assignment instructions)

- [ ] Push this project to your GitHub repository
- [ ] Share the repo privately with `admin@testmuaicertifications.com`
- [ ] Run the suite so at least 2 TestMu AI Test Session IDs are generated
      (one per project) with network logs / video / screenshots / console
      logs enabled
- [ ] Submit the GitHub repo URL + Test Session IDs on the exam portal
      within 36 hours of the deadline
